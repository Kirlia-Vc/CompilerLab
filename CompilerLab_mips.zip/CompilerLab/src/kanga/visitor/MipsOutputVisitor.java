package kanga.visitor;

import kanga.syntaxtree.*;
import mytypes.MipsStmt;

/**
 * Created by Vc on 2017/6/2.
 */
public class MipsOutputVisitor extends GJDepthFirst<String,String> {
    boolean outputSimpleExp=false;
    int spilloffset=0;
    String tempReg="";
    int spillargs=0;
    /**
     * f0 -> "MAIN"
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> "["
     * f5 -> IntegerLiteral()
     * f6 -> "]"
     * f7 -> "["
     * f8 -> IntegerLiteral()
     * f9 -> "]"
     * f10 -> StmtList()
     * f11 -> "END"
     * f12 -> ( Procedure() )*
     * f13 -> <EOF>
     */
    public String visit(Goal n, String argu) {
        System.out.println("\t.text");
        System.out.println("\t.globl\tmain");
        System.out.println("main:");
        int spilled=Integer.valueOf(n.f8.accept(this, argu));
        String subu=spilled<4?"4":String.valueOf(4+(spilled-4)*4);
        new MipsStmt("move","fp","sp").output();
        new MipsStmt("subu","sp","sp",subu).output();
        new MipsStmt("sw","ra","-4","fp").output();
        String _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        n.f5.accept(this, argu);
        n.f6.accept(this, argu);
        n.f7.accept(this, argu);
        n.f8.accept(this, argu);
        n.f9.accept(this, argu);
        n.f10.accept(this, argu);
        n.f11.accept(this, argu);
        new MipsStmt("lw","ra","-4","fp").output();
        new MipsStmt("addu","sp","sp",subu).output();
        new MipsStmt("j","ra").output();
        n.f12.accept(this, argu);
        n.f13.accept(this, argu);
        System.out.println(".text\n" +
                "         .globl _halloc\n" +
                "_halloc:\n" +
                "         li $v0, 9\n" +
                "         syscall\n" +
                "         j $ra\n" +
                "\n" +
                "         .text\n" +
                "         .globl _print\n" +
                "_print:\n" +
                "         li $v0, 1\n" +
                "         syscall\n" +
                "         la $a0, newl\n" +
                "         li $v0, 4\n" +
                "         syscall\n" +
                "         j $ra\n" +
                "\n" +
                "         .data\n" +
                "         .align   0\n" +
                "newl:    .asciiz \"\\n\" \n" +
                "         .data\n" +
                "         .align   0\n" +
                "str_er:  .asciiz \" ERROR: abnormal termination\\n\" ");
        return _ret;
    }
    public String visit(NodeOptional n, String argu) {
        if ( n.present() ){
            System.out.println(n.node.accept(this,argu)+":");
        }
        return null;
    }
    /**
     * f0 -> ( ( Label() )? Stmt() )*
     */
    public String visit(StmtList n, String argu) {
        String _ret=null;

        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> "["
     * f5 -> IntegerLiteral()
     * f6 -> "]"
     * f7 -> "["
     * f8 -> IntegerLiteral()
     * f9 -> "]"
     * f10 -> StmtList()
     * f11 -> "END"
     */
    public String visit(Procedure n, String argu) {
        String _ret=null;
        String f0=n.f0.accept(this, argu);
        String f2=n.f2.accept(this, argu);
        String f5=n.f5.accept(this, argu);
        String f8=n.f8.accept(this,argu);
        spillargs=Integer.parseInt(f2)-4;
        int spillarg=Integer.parseInt(f8)-4;
        int subsp=Integer.parseInt(f5)*4+8;
        if(spillarg>0){
            subsp+=(4*spillarg);
            spilloffset=4*spillarg;
        }
        else
            spilloffset=0;
        System.out.println("\r\n\t.text");
        System.out.println("\t.globl\t"+f0);
        System.out.println(f0+":");
        new MipsStmt("sw","fp","-8","sp").output();
        new MipsStmt("move","fp","sp").output();
        new MipsStmt("subu","sp","sp",String.valueOf(subsp)).output();
        new MipsStmt("sw","ra","-4","fp").output();
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);

        n.f6.accept(this, argu);
        n.f7.accept(this, argu);
        n.f8.accept(this, argu);
        n.f9.accept(this, argu);
        n.f10.accept(this, argu);
        n.f11.accept(this, argu);
        new MipsStmt("lw","ra","-4","fp").output();
        new MipsStmt("addu","sp","sp",String.valueOf(subsp)).output();
        new MipsStmt("lw","fp","-8","sp").output();
        new MipsStmt("j","ra").output();
        return _ret;
    }

    /**
     * f0 -> NoOpStmt()
     *       | ErrorStmt()
     *       | CJumpStmt()
     *       | JumpStmt()
     *       | HStoreStmt()
     *       | HLoadStmt()
     *       | MoveStmt()
     *       | PrintStmt()
     *       | ALoadStmt()
     *       | AStoreStmt()
     *       | PassArgStmt()
     *       | CallStmt()
     */
    public String visit(Stmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "NOOP"
     */
    public String visit(NoOpStmt n, String argu) {
        String _ret=null;
        System.out.println(" nop ");
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "ERROR"
     */
    public String visit(ErrorStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "CJUMP"
     * f1 -> Reg()
     * f2 -> Label()
     */
    public String visit(CJumpStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        String f2=n.f2.accept(this, argu);
        new MipsStmt("beqz",f1,f2).output();
        return _ret;
    }

    /**
     * f0 -> "JUMP"
     * f1 -> Label()
     */
    public String visit(JumpStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        new MipsStmt("b",f1).output();
        return _ret;
    }

    /**
     * f0 -> "HSTORE"
     * f1 -> Reg()
     * f2 -> IntegerLiteral()
     * f3 -> Reg()
     */
    public String visit(HStoreStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        String f2=n.f2.accept(this, argu);
        String f3=n.f3.accept(this, argu);
        new MipsStmt("sw",f3,f2,f1).output();
        return _ret;
    }

    /**
     * f0 -> "HLOAD"
     * f1 -> Reg()
     * f2 -> Reg()
     * f3 -> IntegerLiteral()
     */
    public String visit(HLoadStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        String f2=n.f2.accept(this, argu);
        String f3=n.f3.accept(this, argu);
        new MipsStmt("lw",f1,f3,f2).output();
        return _ret;
    }

    /**
     * f0 -> "MOVE"
     * f1 -> Reg()
     * f2 -> Exp()
     */
    public String visit(MoveStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String regf1=n.f1.accept(this, argu);
        n.f2.accept(this, regf1);
        return _ret;
    }

    /**
     * f0 -> "PRINT"
     * f1 -> SimpleExp()
     */
    public String visit(PrintStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        new MipsStmt("move","a0",f1).output();
        new MipsStmt("jal","_print").output();
        return _ret;
    }

    /**
     * f0 -> "ALOAD"
     * f1 -> Reg()
     * f2 -> SpilledArg()
     */
    public String visit(ALoadStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        String arg=n.f2.accept(this, argu);
        int argno=Integer.valueOf(arg);
        String arg2=String.valueOf(Integer.valueOf(arg)*4);
        String arg2s=String.valueOf(Integer.valueOf(arg)*4+spilloffset);
        if(argno>=spillargs)
            new MipsStmt("lw",f1,arg2s,"sp").output();
        else
            new MipsStmt("lw",f1,arg2,"fp").output();
        return _ret;
    }

    /**
     * f0 -> "ASTORE"
     * f1 -> SpilledArg()
     * f2 -> Reg()
     */
    public String visit(AStoreStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        String reg=n.f2.accept(this, argu);
        String arg2=String.valueOf(Integer.valueOf(f1)*4+spilloffset);
        new MipsStmt("sw",reg,arg2,"sp").output();
        return _ret;
    }

    /**
     * f0 -> "PASSARG"
     * f1 -> IntegerLiteral()
     * f2 -> Reg()
     */
    public String visit(PassArgStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String arg=n.f1.accept(this, argu);
        int offset=(Integer.valueOf(arg)-1)*4;
        String regf2=n.f2.accept(this, argu);

        new MipsStmt("sw",regf2,String.valueOf(offset),"sp").output();

        return _ret;
    }

    /**
     * f0 -> "CALL"
     * f1 -> SimpleExp()
     */
    public String visit(CallStmt n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String f1=n.f1.accept(this, argu);
        new MipsStmt("jalr",f1).output();
        return _ret;
    }

    /**
     * f0 -> HAllocate()
     *       | BinOp()
     *       | SimpleExp()
     */
    public String visit(Exp n, String argu) {
        String _ret=null;
        if(n.f0.which==2)
            outputSimpleExp=true;
        n.f0.accept(this, argu);
        outputSimpleExp=false;
        return _ret;
    }

    /**
     * f0 -> "HALLOCATE"
     * f1 -> SimpleExp()
     */
    public String visit(HAllocate n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        String exp=n.f1.accept(this, argu);
        /*
        if(exp.charAt(0)>='0'&&exp.charAt(0)<='9'){ //number
            new MipsStmt("move","a0",exp).output();

        }
        else if(exp.length()==2&&exp.charAt(0)>='a'&&exp.charAt(0)<='v'){   //reg
            new MipsStmt("move","a0",exp).output();
        }
        */
        new MipsStmt("move","a0",exp).output();
        new MipsStmt("jal","_halloc").output();
        new MipsStmt("move",argu,"v0").output();
        return _ret;
    }

    /**
     * f0 -> Operator()
     * f1 -> Reg()
     * f2 -> SimpleExp()
     */
    public String visit(BinOp n, String argu) {
        String _ret=null;
        String op=n.f0.accept(this, argu);
        String regf1=n.f1.accept(this, argu);
        String f2=n.f2.accept(this, argu);
        MipsStmt ms=new MipsStmt(op,argu,regf1,f2);
        if(f2.charAt(0)>='0'&&f2.charAt(0)<=9)
            ms.name=ms.name+"i";
        ms.output();
        return _ret;
    }

    /**
     * f0 -> "LT"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     */
    public String visit(Operator n, String argu) {
        String _ret=null;
        switch (n.f0.which){
            case 0:
                return "slt";
            case 1:
                return "add";
            case 2:
                return "sub";
            case 3:
                return "mul";
        }
        return n.f0.accept(this, argu);
        //return _ret;
    }

    /**
     * f0 -> "SPILLEDARG"
     * f1 -> IntegerLiteral()
     */
    public String visit(SpilledArg n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        return n.f1.accept(this, null);
    }

    /**
     * f0 -> Reg()
     *       | IntegerLiteral()
     *       | Label()
     */
    public String visit(SimpleExp n, String argu) {
        String _ret=null;
        String f0=n.f0.accept(this, argu);
        if(outputSimpleExp)
            new MipsStmt("move",argu,f0).output();
        return tempReg;
    }

    /**
     * f0 -> "a0"
     *       | "a1"
     *       | "a2"
     *       | "a3"
     *       | "t0"
     *       | "t1"
     *       | "t2"
     *       | "t3"
     *       | "t4"
     *       | "t5"
     *       | "t6"
     *       | "t7"
     *       | "s0"
     *       | "s1"
     *       | "s2"
     *       | "s3"
     *       | "s4"
     *       | "s5"
     *       | "s6"
     *       | "s7"
     *       | "t8"
     *       | "t9"
     *       | "v0"
     *       | "v1"
     */
    public String visit(Reg n, String argu) {
        String _ret=null;
        String regs[]={
                "a0","a1","a2","a3",
                "t0","t1","t2","t3",
                "t4","t5","t6","t7",
                "s0","s1","s2","s3",
                "s4","s5","s6","s7",
                "t8","t9","v0","v1",
        };
        tempReg=regs[n.f0.which];
        return regs[n.f0.which];
    }

    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public String visit(IntegerLiteral n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        tempReg=n.f0.tokenImage;
        return n.f0.tokenImage;
    }

    /**
     * f0 -> <IDENTIFIER>
     */
    public String visit(Label n, String argu) {
        String _ret=null;
        n.f0.accept(this, argu);
        return n.f0.tokenImage;
    }
}
