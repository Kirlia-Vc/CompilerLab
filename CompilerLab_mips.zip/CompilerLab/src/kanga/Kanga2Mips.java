package kanga;


import kanga.syntaxtree.Node;
import kanga.visitor.MipsOutputVisitor;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Created by Vc on 2017/6/2.
 */
public class Kanga2Mips {
    public static void main(String[] args) throws FileNotFoundException, ParseException {
        Node root=new KangaParser(new FileInputStream("testcases/input.kg")).Goal();
        root.accept(new MipsOutputVisitor(),null);
    }
}
