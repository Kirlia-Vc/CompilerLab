package spiglet.visitor;

import mytypes.BasicBlock;
import mytypes.FlowGraph;
import spiglet.Spiglet2Kanga;
import spiglet.syntaxtree.*;

/**
 * Created by Vc on 2017/5/20.
 */
public class FlowGraphVisitor extends GJDepthFirst<FlowGraph, FlowGraph>{
    public String curLabel="";


    public FlowGraph visit(NodeOptional n, FlowGraph argu) {
        if ( n.present() ){

            return n.node.accept(this,argu);
        }
        return null;
    }

    /**
     * f0 -> "MAIN"
     * f1 -> StmtList()
     * f2 -> "END"
     * f3 -> ( Procedure() )*
     * f4 -> <EOF>
     */
    public FlowGraph visit(Goal n, FlowGraph argu) {
        FlowGraph _ret=null;
        argu=Spiglet2Kanga.procMap.get("MAIN");
        argu.curNode=0;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        return _ret;
    }
    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> StmtExp()
     */
    public FlowGraph visit(Procedure n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        String label=n.f0.f0.tokenImage;
        argu=Spiglet2Kanga.procMap.get(label);
        argu.curNode=0;
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        return _ret;
    }
    /**
     * f0 -> NoOpStmt()
     *       | ErrorStmt()
     *       | CJumpStmt()
     *       | JumpStmt()
     *       | HStoreStmt()
     *       | HLoadStmt()
     *       | MoveStmt()
     *       | PrintStmt()
     */
    public FlowGraph visit(Stmt n, FlowGraph argu) {
        FlowGraph _ret=null;


        n.f0.accept(this, argu);
        argu.curNode++;
        return _ret;
    }

    /**
     * f0 -> "NOOP"
     */
    public FlowGraph visit(NoOpStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "ERROR"
     */
    public FlowGraph visit(ErrorStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "CJUMP"
     * f1 -> Temp()
     * f2 -> Label()
     */
    public FlowGraph visit(CJumpStmt n, FlowGraph argu) {
        FlowGraph _ret=null;

        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }
        argu.tempType=true;
        String label=n.f2.f0.tokenImage;
        BasicBlock bbjump=argu.findBBByLabel(label);
        //System.out.println(bb.blockId+" "+bbjump.blockId);
        bbjump.blockin.add(bb);
        bb.blockout.add(bbjump);
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "JUMP"
     * f1 -> Label()
     */
    public FlowGraph visit(JumpStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        String label=n.f1.f0.tokenImage;
        BasicBlock bb=argu.blocks.get(argu.curNode);
        BasicBlock bbjump=argu.findBBByLabel(label);
        bb.blockout.add(bbjump);
        bbjump.blockin.add(bb);
        return _ret;
    }

    /**
     * f0 -> "HSTORE"
     * f1 -> Temp()
     * f2 -> IntegerLiteral()
     * f3 -> Temp()
     */
    public FlowGraph visit(HStoreStmt n, FlowGraph argu) {
        FlowGraph _ret=null;

        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }
        argu.tempType=true;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        argu.tempType=true;
        n.f3.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "HLOAD"
     * f1 -> Temp()
     * f2 -> Temp()
     * f3 -> IntegerLiteral()
     */
    public FlowGraph visit(HLoadStmt n, FlowGraph argu) {
        FlowGraph _ret=null;

        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }
        n.f0.accept(this, argu);
        argu.tempType=false;
        n.f1.accept(this, argu);
        argu.tempType=true;
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "MOVE"
     * f1 -> Temp()
     * f2 -> Exp()
     */
    public FlowGraph visit(MoveStmt n, FlowGraph argu) {
        FlowGraph _ret=null;

        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }
        argu.tempType=false;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        argu.tempType=true;
        n.f2.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "PRINT"
     * f1 -> SimpleExp()
     */
    public FlowGraph visit(PrintStmt n, FlowGraph argu) {
        FlowGraph _ret=null;

        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.curNode+1<argu.blocks.size()){
            BasicBlock bbnext=argu.blocks.get(argu.curNode+1);
            bb.blockout.add(bbnext);
            bbnext.blockin.add(bb);
        }

        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> Call()
     *       | HAllocate()
     *       | BinOp()
     *       | SimpleExp()
     */
    public FlowGraph visit(Exp n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "BEGIN"
     * f1 -> StmtList()
     * f2 -> "RETURN"
     * f3 -> SimpleExp()
     * f4 -> "END"
     */
    public FlowGraph visit(StmtExp n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        argu.curNode--;
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "CALL"
     * f1 -> SimpleExp()
     * f2 -> "("
     * f3 -> ( Temp() )*
     * f4 -> ")"
     */
    public FlowGraph visit(Call n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        argu.tempType=true;
        argu.maxArg=Math.max(argu.maxArg,n.f3.size());  //the max argument of calling
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "HALLOCATE"
     * f1 -> SimpleExp()
     */
    public FlowGraph visit(HAllocate n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> Operator()
     * f1 -> Temp()
     * f2 -> SimpleExp()
     */
    public FlowGraph visit(BinOp n, FlowGraph argu) {
        FlowGraph _ret=null;
        BasicBlock bb=argu.blocks.get(argu.curNode);
        bb.use.add(n.f1.getInt());
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "LT"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     */
    public FlowGraph visit(Operator n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> Temp()
     *       | IntegerLiteral()
     *       | Label()
     */
    public FlowGraph visit(SimpleExp n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "TEMP"
     * f1 -> IntegerLiteral()
     */
    public FlowGraph visit(Temp n, FlowGraph argu) {
        FlowGraph _ret=null;
        BasicBlock bb=argu.blocks.get(argu.curNode);
        if(argu.tempType)
            bb.use.add(n.getInt());
        else
            bb.def.add(n.getInt());
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public FlowGraph visit(IntegerLiteral n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> <IDENTIFIER>
     */
    public FlowGraph visit(Label n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }
}
