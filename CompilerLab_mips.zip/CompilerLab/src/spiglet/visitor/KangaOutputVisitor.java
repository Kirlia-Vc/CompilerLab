package spiglet.visitor;

import minijava.MyOutput;
import mytypes.FlowGraph;
import spiglet.Spiglet2Kanga;
import spiglet.syntaxtree.*;

import java.util.Vector;

/**
 * Created by Vc on 2017/5/21.
 */
public class KangaOutputVisitor extends GJDepthFirst<FlowGraph,FlowGraph> {
    public static String
            ASTORE=" ASTORE ",
            SPILLEDARG=" SPILLEDARG ",
            NOOP=" NOOP ",
            CJUMP=" CJUMP ",
            JUMP= " JUMP ",
            HSTORE= " HSTORE ",
            MOVE= " MOVE ",
            HLOAD=" HLOAD ",
            PRINT=" PRINT ",
            ALOAD=" ALOAD ",
            PASSARG=" PASSARG ",
            CALL=" CALL ",
            LT= " LT ",
            PLUS=" PLUS ",
            MINUS=" MINUS ",
            TIMES=" TIMES ";
    public static String regfile[]={" s0 "," s1 "," s2 "," s3 "," s4 "," s5 "," s6 "," s7 ",
    " t0 "," t1 "," t2 "," t3 "," t4 "," t5 "," t6 "," t7 "};
    int nextV=0;
    static boolean outputLabel=true;
    public String findRegOrStack(int tempid,FlowGraph argu,int v){
        Integer reg=argu.tempReg.get(tempid);
        if(reg==null){
            Integer stackno=argu.tempStack.get(tempid);
            MyOutput.println(ALOAD+" v"+v+" "+SPILLEDARG+stackno);
            return " v"+v+" ";
        }
        return regfile[reg];
    }
    public void saveRegOrStack(int tempid,FlowGraph argu,String src){
        //if(argu.label.equals("BBS_Init"))
        //System.out.println(argu.curNode+" "+argu.startBlock.get(141));
        if(argu.startBlock.get(tempid)==null||argu.startBlock.get(tempid)>argu.curNode+1)
            return;
        Integer reg=argu.tempReg.get(tempid);
        if(reg==null){
            Integer stackno=argu.tempStack.get(tempid);
            if(stackno==null)
                return;
            MyOutput.println(ASTORE+SPILLEDARG+stackno+src);
            return;
        }
        MyOutput.println(MOVE+regfile[reg]+src);
    }
    public FlowGraph visit(NodeOptional n, FlowGraph argu) {
        if ( n.present() ){
            outputLabel=true;
            return n.node.accept(this,argu);
        }
        return null;
    }
    /**
     * f0 -> "MAIN"
     * f1 -> StmtList()
     * f2 -> "END"
     * f3 -> ( Procedure() )*
     * f4 -> <EOF>
     */
    public FlowGraph visit(Goal n, FlowGraph argu) {
        FlowGraph _ret=null;
        argu= Spiglet2Kanga.procMap.get("MAIN");
        argu.curNode=0;
        MyOutput.println("MAIN"+" [0] ["+argu.stackNo+"] ["+argu.maxArg+"]");

        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        MyOutput.println("END");
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);

        return _ret;
    }

    /**
     * f0 -> ( ( Label() )? Stmt() )*
     */
    public FlowGraph visit(StmtList n, FlowGraph argu) {
        FlowGraph _ret=null;
        outputLabel=true;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> Label()
     * f1 -> "["
     * f2 -> IntegerLiteral()
     * f3 -> "]"
     * f4 -> StmtExp()
     */
    public FlowGraph visit(Procedure n, FlowGraph argu) {
        FlowGraph _ret=null;
        argu=Spiglet2Kanga.procMap.get(n.f0.f0.tokenImage);
        argu.curNode=0;
        int argNum=Integer.valueOf(n.f2.f0.tokenImage);
        MyOutput.println(n.f0.f0.tokenImage+" ["+n.f2.f0.tokenImage+"] ["+argu.stackNo+"] ["+argu.maxArg+"]");
        int offset=Math.max(0,argNum-4);
        for(int i=0;i<Math.min(argu.stackNo,8);i++){
            MyOutput.println(ASTORE+SPILLEDARG+String.valueOf(i+offset)+regfile[i]);
        }
        if(argNum<=4){  //temp0~temp3:a0-a3
            for(int i=0;i<argNum;i++){
                saveRegOrStack(i,argu,"a"+i);
            }
        }
        else{
            for(int i=0;i<4;i++){
                saveRegOrStack(i,argu,"a"+i);
            }
            for(int i=4;i<argNum;i++){
                MyOutput.println(ALOAD+" v0 "+SPILLEDARG+(i-4));
                saveRegOrStack(i,argu," v0 ");
            }
        }
        //n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        for(int i=0;i<Math.min(argu.stackNo,8);i++){
            MyOutput.println(ALOAD+regfile[i]+SPILLEDARG+String.valueOf(i+offset));
        }
        MyOutput.println(" END");

        return _ret;
    }

    /**
     * f0 -> NoOpStmt()
     *       | ErrorStmt()
     *       | CJumpStmt()
     *       | JumpStmt()
     *       | HStoreStmt()
     *       | HLoadStmt()
     *       | MoveStmt()
     *       | PrintStmt()
     */
    public FlowGraph visit(Stmt n, FlowGraph argu) {

        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        System.out.println("");
        argu.curNode++;
        return _ret;
    }

    /**
     * f0 -> "NOOP"
     */
    public FlowGraph visit(NoOpStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "ERROR"
     */
    public FlowGraph visit(ErrorStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "CJUMP"
     * f1 -> Temp()
     * f2 -> Label()
     */
    public FlowGraph visit(CJumpStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        int tempid=n.f1.getInt();
        String regName=findRegOrStack(tempid,argu,1);
        MyOutput.println(CJUMP+regName+n.f2.f0.tokenImage);
        n.f0.accept(this, argu);
        //n.f1.accept(this, argu);
        //n.f2.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "JUMP"
     * f1 -> Label()
     */
    public FlowGraph visit(JumpStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        MyOutput.println(JUMP+n.f1.f0.tokenImage);
        n.f0.accept(this, argu);
        //n.f1.accept(this, argu);

        return _ret;
    }

    /**
     * f0 -> "HSTORE"
     * f1 -> Temp()
     * f2 -> IntegerLiteral()
     * f3 -> Temp()
     */
    public FlowGraph visit(HStoreStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        int tempf1=n.f1.getInt();
        int tempf3=n.f3.getInt();
        String regf1=findRegOrStack(tempf1,argu,0);
        String regf3=findRegOrStack(tempf3,argu,1);
        MyOutput.println(HSTORE+regf1+n.f2.f0.tokenImage+regf3);
        n.f0.accept(this, argu);
        //n.f1.accept(this, argu);
        //n.f2.accept(this, argu);
        //n.f3.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "HLOAD"
     * f1 -> Temp()
     * f2 -> Temp()
     * f3 -> IntegerLiteral()
     */
    public FlowGraph visit(HLoadStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        int tempf1=n.f1.getInt();
        int tempf2=n.f2.getInt();
        String regf2=findRegOrStack(tempf2,argu,1);
        MyOutput.println(HLOAD+" v0 "+regf2+n.f3.f0.tokenImage);
        saveRegOrStack(tempf1,argu," v0 ");
        n.f0.accept(this, argu);
        //n.f1.accept(this, argu);
        //n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "MOVE"
     * f1 -> Temp()
     * f2 -> Exp()
     */
    public FlowGraph visit(MoveStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        //String reg=findRegOrStack(n.f1.getInt(),argu,1);
        n.f2.accept(this, argu);
        //result in v0
        saveRegOrStack(n.f1.getInt(),argu," v0 ");
        return _ret;
    }

    /**
     * f0 -> "PRINT"
     * f1 -> SimpleExp()
     */
    public FlowGraph visit(PrintStmt n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        MyOutput.println(PRINT+" v0 ");
        return _ret;
    }

    /**
     * f0 -> Call()
     *       | HAllocate()
     *       | BinOp()
     *       | SimpleExp()
     */
    public FlowGraph visit(Exp n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        //store in v0
        return _ret;
    }

    /**
     * f0 -> "BEGIN"
     * f1 -> StmtList()
     * f2 -> "RETURN"
     * f3 -> SimpleExp()
     * f4 -> "END"
     */
    public FlowGraph visit(StmtExp n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        n.f2.accept(this, argu);
        n.f3.accept(this, argu);
        n.f4.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> "CALL"
     * f1 -> SimpleExp()
     * f2 -> "("
     * f3 -> ( Temp() )*
     * f4 -> ")"
     */
    public FlowGraph visit(Call n, FlowGraph argu) {
        FlowGraph _ret=null;
        Vector<Node> callArgs=n.f3.nodes;

        if(callArgs.size()<=4){
            for(int i=0;i<callArgs.size();i++){
                String reg=findRegOrStack(((Temp)callArgs.get(i)).getInt(),argu,0);
                MyOutput.println(MOVE+" a"+i+reg);
            }
        }
        else{
            for(int i=0;i<4;i++){
                String reg=findRegOrStack(((Temp)callArgs.get(i)).getInt(),argu,0);
                MyOutput.println(MOVE+" a"+i+reg);
            }
            for(int i=4;i<callArgs.size();i++){
                String reg=findRegOrStack(((Temp)callArgs.get(i)).getInt(),argu,0);
                MyOutput.println(PASSARG+(i-4+1)+reg);
            }
        }
        n.f1.accept(this, argu);
        MyOutput.println(CALL+"v0");
        return _ret;
    }

    /**
     * f0 -> "HALLOCATE"
     * f1 -> SimpleExp()
     */
    public FlowGraph visit(HAllocate n, FlowGraph argu) {
        FlowGraph _ret=null;
        n.f0.accept(this, argu);
        n.f1.accept(this, argu);
        MyOutput.println(MOVE+" v0 HALLOCATE v0");
        return _ret;
    }

    /**
     * f0 -> Operator()
     * f1 -> Temp()
     * f2 -> SimpleExp()
     */
    public FlowGraph visit(BinOp n, FlowGraph argu) {
        FlowGraph _ret=null;

        String regf1=findRegOrStack(n.f1.getInt(),argu,0);
        //n.f1.accept(this, argu);

        n.f2.accept(this, argu);

        MyOutput.print(MOVE+" v0 ");
        n.f0.accept(this, argu);
        MyOutput.println(regf1+" v0 ");
        return _ret;
    }

    /**
     * f0 -> "LT"
     *       | "PLUS"
     *       | "MINUS"
     *       | "TIMES"
     */
    public FlowGraph visit(Operator n, FlowGraph argu) {
        FlowGraph _ret=null;
        String [] ops={" LT "," PLUS "," MINUS ", " TIMES "};
        MyOutput.print(ops[n.f0.which]);
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> Temp()
     *       | IntegerLiteral()
     *       | Label()
     */
    public FlowGraph visit(SimpleExp n, FlowGraph argu) {
        FlowGraph _ret=null;
        outputLabel=false;
        n.f0.accept(this, argu);
        MyOutput.println(MOVE+" v0 "+argu.curReg);
        return _ret;
    }

    /**
     * f0 -> "TEMP"
     * f1 -> IntegerLiteral()
     */
    public FlowGraph visit(Temp n, FlowGraph argu) {
        FlowGraph _ret=null;

        argu.curReg= findRegOrStack(n.getInt(),argu,nextV);
        return argu;
    }

    /**
     * f0 -> <INTEGER_LITERAL>
     */
    public FlowGraph visit(IntegerLiteral n, FlowGraph argu) {
        FlowGraph _ret=null;
        argu.curReg=n.f0.toString();
        n.f0.accept(this, argu);
        return _ret;
    }

    /**
     * f0 -> <IDENTIFIER>
     */
    public FlowGraph visit(Label n, FlowGraph argu) {
        FlowGraph _ret=null;
        if(outputLabel)
            MyOutput.print(n.f0.tokenImage+" NOOP ");
        outputLabel=false;
        argu.curReg=n.f0.tokenImage;
        n.f0.accept(this, argu);
        return _ret;
    }
}
