package spiglet;

import mytypes.FlowGraph;
import spiglet.syntaxtree.Node;
import spiglet.visitor.BuildFlowGraphVisitor;
import spiglet.visitor.FlowGraphVisitor;
import spiglet.visitor.KangaOutputVisitor;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;

/**
 * Created by Vc on 2017/5/17.
 */
public class Spiglet2Kanga {
    public static HashMap<String, FlowGraph> procMap=new HashMap<>();
    public static void main(String[] args){
        try {
            Node root=new SpigletParser(new FileInputStream("testcases/input.spg")).Goal();

            root.accept(new BuildFlowGraphVisitor(),null);
            root.accept(new FlowGraphVisitor(),null);

            //activated analysis
            for(FlowGraph fg:procMap.values()){
                fg.acitveAnalysis();
                fg.LSRA();
            }
            root.accept(new KangaOutputVisitor(),null);
            /*
            while(!finish){
                finish=true;
                for(FlowGraph fg:procMap.values()){
                    for(int i=fg.blocks.size()-1;i>=0;i--){
                        BasicBlock bb=fg.blocks.get(i);
                        HashSet<Integer> out=new HashSet<>();
                        for(BasicBlock bbout:bb.blockout){
                            out.addAll(bbout.tmpin);
                        }
                        HashSet<Integer> in=new HashSet<>();
                        in.addAll(out);
                        in.removeAll(bb.def);
                        in.addAll(bb.use);
                        if(!in.equals(bb.tmpin)){
                            bb.tmpin=in;
                            finish=false;
                        }
                    }
                }
            }
            // calculate the range of every TEMPs
            for(FlowGraph fg:procMap.values()){
                for(BasicBlock bb:fg.blocks){
                    for(Integer temp:bb.tmpin){
                        Integer p=fg.startBlock.get(temp);
                        if(p==null||p>bb.blockId)
                            fg.startBlock.put(temp,bb.blockId);
                        Integer e=fg.endBlock.get(temp);
                        if(e==null||e<bb.blockId)
                            fg.endBlock.put(temp,bb.blockId);
                    }
                }
            }
            //register allocation

            LSRA();
            */
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}
