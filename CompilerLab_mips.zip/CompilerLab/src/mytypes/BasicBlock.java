package mytypes;

import spiglet.syntaxtree.Stmt;

import java.util.HashSet;
/**
 * Created by Vc on 2017/5/19.
 */
public class BasicBlock {
    public HashSet<BasicBlock> blockin;
    public HashSet<BasicBlock> blockout;
    public HashSet<Integer> use;
    public HashSet<Integer> def;
    public HashSet<Integer> tmpin;
    public HashSet<Integer> tmpout;
    public String label;
    public Stmt stmt;
    public int blockId;
    public boolean isCall;
    public BasicBlock(String label,Stmt stmt){
        this.blockout=new HashSet<>();
        this.blockin=new HashSet<>();
        this.tmpin=new HashSet<>();
        this.tmpout=new HashSet<>();
        def=new HashSet<>();
        use=new HashSet<>();
        this.label=label;
        this.stmt=stmt;
        isCall=false;
    }
}
