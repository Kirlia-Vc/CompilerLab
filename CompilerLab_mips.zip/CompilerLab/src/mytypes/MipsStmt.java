package mytypes;

import java.util.HashSet;

/**
 * Created by Vc on 2017/6/2.
 */
public class MipsStmt {
    public String name;
    public String arg1,arg2,arg3;
    public String[] _binop3={
            "add","addi","sub","subi","mul","and"
    };
    public String[] _op2={
            "move","li","la","beqz"
    };
    public static String regs[]={
            "a0","a1","a2","a3",
            "t0","t1","t2","t3",
            "t4","t5","t6","t7",
            "s0","s1","s2","s3",
            "s4","s5","s6","s7",
            "t8","t9","v0","v1",
            "ra"
    };

    public static HashSet<String> op2=new HashSet<String>(){
        {
            add("move");
            add("li");
            add("la");
            add("beqz");
        }
    };
    public static HashSet<String> binop3=new HashSet<String>(){
        {
            add("add");
            add("addu");
            add("sub");
            add("subu");
            add("mul");
            add("and");
            add("slt");
            add("slti");
        }
    };
    public static HashSet<String> op1=new HashSet<String>(){
        {
            add("j");
            add("b");
            add("jal");
            add("jalr");
        }
    };
    public void output(){
        System.out.print("\t"+name+" ");
        if(op2.contains(name)){
            if(arg2.charAt(0)>='0'&&arg2.charAt(0)<='9'||arg2.length()>2||arg2.charAt(0)=='L')
                System.out.println("$"+arg1+" "+arg2);
            else
                System.out.println("$"+arg1+" $"+arg2);

            return;
        }
        if(binop3.contains(name)){
            if(arg3.charAt(0)>='0'&&arg3.charAt(0)<='9')
                System.out.println("$"+arg1+" ,$"+arg2+" ,"+arg3);
            else
                System.out.println("$"+arg1+" ,$"+arg2+" ,$"+arg3);
            return;
        }
        if(name.equals("lw")||name.equals("sw")){
            System.out.println("$"+arg1+", "+arg2+"($"+arg3+")");
            return;
        }
        if(op1.contains(name)){
            System.out.println(arg1);
            return;

        }
        System.out.println("");
    }
    public MipsStmt(String name,String arg1,String arg2,String arg3){
        this.name=name;
        this.arg1=arg1;
        this.arg2=arg2;
        this.arg3=arg3;
    }
    public MipsStmt(String name,String arg1,String arg2){

        this.name=name;
        if(name.equals("move")){
            if(arg2.charAt(0)>='0'&&arg2.charAt(0)<='9')
                this.name="li";
            else if(arg2.charAt(0)>='a'&&arg2.charAt(0)<='v'&&arg2.length()==2)
                ;
            else
                this.name="la";
        }
        this.arg1=arg1;
        this.arg2=arg2;
    }
    public MipsStmt(String name,String arg1){
        this.name=name;
        this.arg1=arg1;
        for(String a:regs){
            if(a.equals(arg1))
                this.arg1="$"+this.arg1;
        }
    }

}
