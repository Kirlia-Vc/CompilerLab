package minijava;

public class MyOutput {
	public static void error(String r){
		System.out.println("Error: "+r);
	}
	public static void println(String r){
	    System.out.println(r);
    }
    public static void print(String r){
	    System.out.print(r);
    }
}
