package minijava;

import java.util.HashMap;

public class ArgumentTable {
	
	
}
