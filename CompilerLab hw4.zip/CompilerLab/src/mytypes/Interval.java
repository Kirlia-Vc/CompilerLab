package mytypes;

/**
 * Created by Vc on 2017/5/21.
 */
public class Interval {
    public int tempId;
    public int blockId;
    public Interval(int _a,int _b){
        tempId=_a;
        blockId=_b;
    }
}
