package mytypes;

import minijava.MyOutput;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;

/**
 * Created by Vc on 2017/5/20.
 */
public class FlowGraph {
    public static int REGNUM=18;
    public HashSet<Integer> active=new HashSet<>();
    public ArrayList<BasicBlock> blocks;
    public HashMap<Integer,Integer> startBlock;
    public HashMap<Integer,Integer> endBlock;
    public HashMap<Integer,Integer> tempReg;
    public HashMap<Integer,Integer> tempStack;
    public boolean []Regs= new boolean[REGNUM];     //s0-s7,t0-t9
    public String label;
    public int stackNo;
    public int maxArg;
    public String curReg;
    public HashSet<Integer> crossCallingTemps;
    public FlowGraph(String label){
        for(int i=0;i<REGNUM;i++)
            Regs[i]=true;
        blocks=new ArrayList<>();
        startBlock=new HashMap<>();
        endBlock=new HashMap<>();
        tempReg=new HashMap<>();
        tempStack=new HashMap<>();
        crossCallingTemps=new HashSet<>();
        this.label=label;
        stackNo=0;
        curNode=0;
    }
    public int curNode;
    public boolean tempType;    //use-true,def-false
    public BasicBlock findBBByLabel(String label){
        for(BasicBlock bb:blocks){
            if(bb.label!=null&&bb.label.equals(label))
                return bb;
        }
        MyOutput.println("ERR");
        return null;
    }
    public void acitveAnalysis(){
        boolean finish=false;
        while(!finish){
            finish=true;
            for(int i=blocks.size()-1;i>=0;i--){
                BasicBlock bb=blocks.get(i);
                HashSet<Integer> out=new HashSet<>();
                for(BasicBlock bbout:bb.blockout){

                    out.addAll(bbout.tmpin);
                }
                HashSet<Integer> in=new HashSet<>();
                in.addAll(out);
                in.removeAll(bb.def);
                in.addAll(bb.use);
                if(!in.equals(bb.tmpin)){
                    bb.tmpin=in;
                    finish=false;
                }
            }
        }
        for(BasicBlock bb:blocks){
            for(Integer temp:bb.tmpin){
                //if(label.equals("BBS_Init")&&temp==0)
                //    System.out.println(bb.blockId+" "+startBlock.get(temp)+" "+endBlock.get(temp));
                Integer p=startBlock.get(temp);
                if(p==null||p>bb.blockId)
                    startBlock.put(temp,bb.blockId);
                Integer e=endBlock.get(temp);
                if(e==null||e<bb.blockId)
                    endBlock.put(temp,bb.blockId);
                if(bb.isCall)
                    crossCallingTemps.add(temp);
                //if(label.equals("BBS_Init")&&temp==0)
                //    System.out.println(startBlock.get(temp)+" "+endBlock.get(temp));
            }
        }
    }
    public void LSRA(){

        //System.out.println(label);
        int maxRegNo=0;
        ArrayList<Interval> startPoints=new ArrayList<>();
        ArrayList<Interval> endPoints=new ArrayList<>();
        for(HashMap.Entry e:startBlock.entrySet()){
            startPoints.add(new Interval((int)e.getKey(),(int)e.getValue()));
        }
        for(HashMap.Entry e:endBlock.entrySet()){
            endPoints.add(new Interval((int)e.getKey(),(int)e.getValue()));
        }
        startPoints.sort(Comparator.comparingInt(o -> o.blockId));
        endPoints.sort(Comparator.comparingInt(o->o.blockId));
        for(Interval i:startPoints){
            // expireOldIntervals(i);
            //System.out.println(i.tempId);
            for(Interval j:endPoints){

                if(!active.contains(j.tempId))  //NOT ACTIVE
                    continue;
                if(j.blockId>=i.blockId)        //ENDPOINT J > STARTPOINT I
                    continue;
                //if(label.equals("BBS_Init")&&j.tempId==0)
                //    System.out.println(j.tempId+" "+i.tempId);
                active.remove(j.tempId);
                Integer regj=tempReg.get(j.tempId);
                Regs[regj]=true;
            }
            if(active.size()==REGNUM        //no register
                    ||
                    (crossCallingTemps.contains(i.tempId)&&active.size()>=8)){  //cross call
                //SpillAtInterval(i)
                //get the last active temp
                int lastid=0,lastblock=0;
                for(Integer ac:active){
                    if(lastblock<endBlock.get(ac)){
                        lastblock=endBlock.get(ac);
                        lastid=ac;
                    }
                }
                if(lastblock<endBlock.get(i.tempId)){
                    tempStack.put(i.tempId,stackNo+8);    //put in stack
                    stackNo++;
                }
                else{
                    active.remove(lastid);
                    active.add(i.tempId);
                    tempStack.put(lastid,stackNo+8);
                    stackNo++;
                    tempReg.put(i.tempId,tempReg.get(lastid));
                    tempReg.remove(lastid);
                }
            }
            else{       //assign a register
                active.add(i.tempId);
                for(int b=0;b<REGNUM;b++){
                    if(Regs[b]){
                        Regs[b]=false;
                        tempReg.put(i.tempId,b);
                        maxRegNo=Math.max(maxRegNo,b);
                        //if(label.equals("BBS_Init"))
                        //System.out.println("ASSIGN "+i.tempId+" "+b);
                        break;
                    }
                }
            }

        }
        stackNo+=Math.min(maxRegNo,8);
        ///System.out.println(tempReg.size());
    }
}
